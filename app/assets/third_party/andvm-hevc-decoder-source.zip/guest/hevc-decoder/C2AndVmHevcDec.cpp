/*
 * Copyright (C) 2018 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

//#define LOG_NDEBUG 0
#define LOG_TAG "AndVmHevcDecoder"
#include <log/log.h>
#include <C2PlatformSupport.h>
#include <Codec2Mapper.h>
#include <SimpleC2Component.h>
#include <SimpleC2Interface.h>
#include <util/C2InterfaceHelper.h>
#include <media/stagefright/MediaDefs.h>
#include <media/stagefright/foundation/ColorUtils.h>
#include <libde265/de265.h>
#include <algorithm>
#include <cstring>
#include <unistd.h>

namespace android {
namespace {
constexpr char COMPONENT_NAME[] = "c2.android.hevc.decoder";
constexpr uint32_t kDefaultOutputDelay = 8, kMaxOutputDelay = 16;
constexpr size_t kMinInputBufferSize = 6 * 1024 * 1024;
}
class C2SoftHevcDec : public SimpleC2Component {
public:
    class IntfImpl;
    C2SoftHevcDec(const char*, c2_node_id_t, const std::shared_ptr<IntfImpl>&);
    ~C2SoftHevcDec() override { onRelease(); }
    c2_status_t onInit() override;
    c2_status_t onStop() override;
    void onReset() override { onStop(); }
    void onRelease() override;
    c2_status_t onFlush_sm() override { return onStop(); }
    void process(const std::unique_ptr<C2Work>&, const std::shared_ptr<C2BlockPool>&) override;
    c2_status_t drain(uint32_t, const std::shared_ptr<C2BlockPool>&) override;
private:
    c2_status_t decode(const std::shared_ptr<C2BlockPool>&, const std::unique_ptr<C2Work>&);
    c2_status_t output(const de265_image*, const std::shared_ptr<C2BlockPool>&,
                       const std::unique_ptr<C2Work>&);
    std::shared_ptr<IntfImpl> mIntf;
    de265_decoder_context* mDecoder = nullptr;
    bool mEos = false, mError = false;
    int mWidth = 0, mHeight = 0;
};
class C2SoftHevcDec::IntfImpl : public SimpleInterface<void>::BaseParams {
public:
    explicit IntfImpl(const std::shared_ptr<C2ReflectorHelper> &helper)
        : SimpleInterface<void>::BaseParams(
                helper,
                COMPONENT_NAME,
                C2Component::KIND_DECODER,
                C2Component::DOMAIN_VIDEO,
                MEDIA_MIMETYPE_VIDEO_HEVC) {
        noPrivateBuffers(); // TODO: account for our buffers here
        noInputReferences();
        noOutputReferences();
        noInputLatency();
        noTimeStretch();

        // TODO: Proper support for reorder depth.
        addParameter(
                DefineParam(mActualOutputDelay, C2_PARAMKEY_OUTPUT_DELAY)
                .withDefault(new C2PortActualDelayTuning::output(kDefaultOutputDelay))
                .withFields({C2F(mActualOutputDelay, value).inRange(0, kMaxOutputDelay)})
                .withSetter(Setter<decltype(*mActualOutputDelay)>::StrictValueWithNoDeps)
                .build());

        addParameter(
                DefineParam(mAttrib, C2_PARAMKEY_COMPONENT_ATTRIBUTES)
                .withConstValue(new C2ComponentAttributesSetting(C2Component::ATTRIB_IS_TEMPORAL))
                .build());

        addParameter(
                DefineParam(mSize, C2_PARAMKEY_PICTURE_SIZE)
                .withDefault(new C2StreamPictureSizeInfo::output(0u, 320, 240))
                .withFields({
                    C2F(mSize, width).inRange(2, 4096, 2),
                    C2F(mSize, height).inRange(2, 4096, 2),
                })
                .withSetter(SizeSetter)
                .build());

        addParameter(
                DefineParam(mProfileLevel, C2_PARAMKEY_PROFILE_LEVEL)
                .withDefault(new C2StreamProfileLevelInfo::input(0u,
                        C2Config::PROFILE_HEVC_MAIN, C2Config::LEVEL_HEVC_MAIN_5_1))
                .withFields({
                    C2F(mProfileLevel, profile).oneOf({
                            C2Config::PROFILE_HEVC_MAIN,
                            C2Config::PROFILE_HEVC_MAIN_STILL,
                            C2Config::PROFILE_HEVC_MAIN_10}),
                    C2F(mProfileLevel, level).oneOf({
                            C2Config::LEVEL_HEVC_MAIN_1,
                            C2Config::LEVEL_HEVC_MAIN_2, C2Config::LEVEL_HEVC_MAIN_2_1,
                            C2Config::LEVEL_HEVC_MAIN_3, C2Config::LEVEL_HEVC_MAIN_3_1,
                            C2Config::LEVEL_HEVC_MAIN_4, C2Config::LEVEL_HEVC_MAIN_4_1,
                            C2Config::LEVEL_HEVC_MAIN_5, C2Config::LEVEL_HEVC_MAIN_5_1,
                            C2Config::LEVEL_HEVC_MAIN_5_2, C2Config::LEVEL_HEVC_HIGH_4,
                            C2Config::LEVEL_HEVC_HIGH_4_1, C2Config::LEVEL_HEVC_HIGH_5,
                            C2Config::LEVEL_HEVC_HIGH_5_1, C2Config::LEVEL_HEVC_HIGH_5_2
                    })
                })
                .withSetter(ProfileLevelSetter, mSize)
                .build());

        addParameter(
                DefineParam(mMaxSize, C2_PARAMKEY_MAX_PICTURE_SIZE)
                .withDefault(new C2StreamMaxPictureSizeTuning::output(0u, 320, 240))
                .withFields({
                    C2F(mSize, width).inRange(2, 4096, 2),
                    C2F(mSize, height).inRange(2, 4096, 2),
                })
                .withSetter(MaxPictureSizeSetter, mSize)
                .build());

        addParameter(
                DefineParam(mMaxInputSize, C2_PARAMKEY_INPUT_MAX_BUFFER_SIZE)
                .withDefault(new C2StreamMaxBufferSizeInfo::input(0u, kMinInputBufferSize))
                .withFields({
                    C2F(mMaxInputSize, value).any(),
                })
                .calculatedAs(MaxInputSizeSetter, mMaxSize)
                .build());

        C2ChromaOffsetStruct locations[1] = { C2ChromaOffsetStruct::ITU_YUV_420_0() };
        std::shared_ptr<C2StreamColorInfo::output> defaultColorInfo =
            C2StreamColorInfo::output::AllocShared(
                    1u, 0u, 8u /* bitDepth */, C2Color::YUV_420);
        memcpy(defaultColorInfo->m.locations, locations, sizeof(locations));

        defaultColorInfo = C2StreamColorInfo::output::AllocShared(
            {C2ChromaOffsetStruct::ITU_YUV_420_0()}, 0u, 8u /* bitDepth */,
            C2Color::YUV_420);
        helper->addStructDescriptors<C2ChromaOffsetStruct>();

        addParameter(
                DefineParam(mColorInfo, C2_PARAMKEY_CODED_COLOR_INFO)
                .withConstValue(defaultColorInfo)
                .build());

        addParameter(
                DefineParam(mDefaultColorAspects, C2_PARAMKEY_DEFAULT_COLOR_ASPECTS)
                .withDefault(new C2StreamColorAspectsTuning::output(
                        0u, C2Color::RANGE_UNSPECIFIED, C2Color::PRIMARIES_UNSPECIFIED,
                        C2Color::TRANSFER_UNSPECIFIED, C2Color::MATRIX_UNSPECIFIED))
                .withFields({
                    C2F(mDefaultColorAspects, range).inRange(
                                C2Color::RANGE_UNSPECIFIED,     C2Color::RANGE_OTHER),
                    C2F(mDefaultColorAspects, primaries).inRange(
                                C2Color::PRIMARIES_UNSPECIFIED, C2Color::PRIMARIES_OTHER),
                    C2F(mDefaultColorAspects, transfer).inRange(
                                C2Color::TRANSFER_UNSPECIFIED,  C2Color::TRANSFER_OTHER),
                    C2F(mDefaultColorAspects, matrix).inRange(
                                C2Color::MATRIX_UNSPECIFIED,    C2Color::MATRIX_OTHER)
                })
                .withSetter(DefaultColorAspectsSetter)
                .build());

        addParameter(
                DefineParam(mCodedColorAspects, C2_PARAMKEY_VUI_COLOR_ASPECTS)
                .withDefault(new C2StreamColorAspectsInfo::input(
                        0u, C2Color::RANGE_LIMITED, C2Color::PRIMARIES_UNSPECIFIED,
                        C2Color::TRANSFER_UNSPECIFIED, C2Color::MATRIX_UNSPECIFIED))
                .withFields({
                    C2F(mCodedColorAspects, range).inRange(
                                C2Color::RANGE_UNSPECIFIED,     C2Color::RANGE_OTHER),
                    C2F(mCodedColorAspects, primaries).inRange(
                                C2Color::PRIMARIES_UNSPECIFIED, C2Color::PRIMARIES_OTHER),
                    C2F(mCodedColorAspects, transfer).inRange(
                                C2Color::TRANSFER_UNSPECIFIED,  C2Color::TRANSFER_OTHER),
                    C2F(mCodedColorAspects, matrix).inRange(
                                C2Color::MATRIX_UNSPECIFIED,    C2Color::MATRIX_OTHER)
                })
                .withSetter(CodedColorAspectsSetter)
                .build());

        addParameter(
                DefineParam(mColorAspects, C2_PARAMKEY_COLOR_ASPECTS)
                .withDefault(new C2StreamColorAspectsInfo::output(
                        0u, C2Color::RANGE_UNSPECIFIED, C2Color::PRIMARIES_UNSPECIFIED,
                        C2Color::TRANSFER_UNSPECIFIED, C2Color::MATRIX_UNSPECIFIED))
                .withFields({
                    C2F(mColorAspects, range).inRange(
                                C2Color::RANGE_UNSPECIFIED,     C2Color::RANGE_OTHER),
                    C2F(mColorAspects, primaries).inRange(
                                C2Color::PRIMARIES_UNSPECIFIED, C2Color::PRIMARIES_OTHER),
                    C2F(mColorAspects, transfer).inRange(
                                C2Color::TRANSFER_UNSPECIFIED,  C2Color::TRANSFER_OTHER),
                    C2F(mColorAspects, matrix).inRange(
                                C2Color::MATRIX_UNSPECIFIED,    C2Color::MATRIX_OTHER)
                })
                .withSetter(ColorAspectsSetter, mDefaultColorAspects, mCodedColorAspects)
                .build());

        // TODO: support more formats?
        addParameter(
                DefineParam(mPixelFormat, C2_PARAMKEY_PIXEL_FORMAT)
                .withConstValue(new C2StreamPixelFormatInfo::output(
                                     0u, HAL_PIXEL_FORMAT_YCBCR_420_888))
                .build());
    }

    static C2R SizeSetter(bool mayBlock, const C2P<C2StreamPictureSizeInfo::output> &oldMe,
                          C2P<C2StreamPictureSizeInfo::output> &me) {
        (void)mayBlock;
        C2R res = C2R::Ok();
        if (!me.F(me.v.width).supportsAtAll(me.v.width)) {
            res = res.plus(C2SettingResultBuilder::BadValue(me.F(me.v.width)));
            me.set().width = oldMe.v.width;
        }
        if (!me.F(me.v.height).supportsAtAll(me.v.height)) {
            res = res.plus(C2SettingResultBuilder::BadValue(me.F(me.v.height)));
            me.set().height = oldMe.v.height;
        }
        return res;
    }

    static C2R MaxPictureSizeSetter(bool mayBlock, C2P<C2StreamMaxPictureSizeTuning::output> &me,
                                    const C2P<C2StreamPictureSizeInfo::output> &size) {
        (void)mayBlock;
        // TODO: get max width/height from the size's field helpers vs. hardcoding
        me.set().width = c2_min(c2_max(me.v.width, size.v.width), 4096u);
        me.set().height = c2_min(c2_max(me.v.height, size.v.height), 4096u);
        return C2R::Ok();
    }

    static C2R MaxInputSizeSetter(bool mayBlock, C2P<C2StreamMaxBufferSizeInfo::input> &me,
                                  const C2P<C2StreamMaxPictureSizeTuning::output> &maxSize) {
        (void)mayBlock;
        // assume compression ratio of 2, but enforce a floor
        me.set().value = c2_max((((maxSize.v.width + 63) / 64)
                    * ((maxSize.v.height + 63) / 64) * 3072), kMinInputBufferSize);
        return C2R::Ok();
    }

    static C2R ProfileLevelSetter(bool mayBlock, C2P<C2StreamProfileLevelInfo::input> &me,
                                  const C2P<C2StreamPictureSizeInfo::output> &size) {
        (void)mayBlock;
        (void)size;
        (void)me;  // TODO: validate
        return C2R::Ok();
    }

    static C2R DefaultColorAspectsSetter(bool mayBlock, C2P<C2StreamColorAspectsTuning::output> &me) {
        (void)mayBlock;
        if (me.v.range > C2Color::RANGE_OTHER) {
                me.set().range = C2Color::RANGE_OTHER;
        }
        if (me.v.primaries > C2Color::PRIMARIES_OTHER) {
                me.set().primaries = C2Color::PRIMARIES_OTHER;
        }
        if (me.v.transfer > C2Color::TRANSFER_OTHER) {
                me.set().transfer = C2Color::TRANSFER_OTHER;
        }
        if (me.v.matrix > C2Color::MATRIX_OTHER) {
                me.set().matrix = C2Color::MATRIX_OTHER;
        }
        return C2R::Ok();
    }

    static C2R CodedColorAspectsSetter(bool mayBlock, C2P<C2StreamColorAspectsInfo::input> &me) {
        (void)mayBlock;
        if (me.v.range > C2Color::RANGE_OTHER) {
                me.set().range = C2Color::RANGE_OTHER;
        }
        if (me.v.primaries > C2Color::PRIMARIES_OTHER) {
                me.set().primaries = C2Color::PRIMARIES_OTHER;
        }
        if (me.v.transfer > C2Color::TRANSFER_OTHER) {
                me.set().transfer = C2Color::TRANSFER_OTHER;
        }
        if (me.v.matrix > C2Color::MATRIX_OTHER) {
                me.set().matrix = C2Color::MATRIX_OTHER;
        }
        return C2R::Ok();
    }

    static C2R ColorAspectsSetter(bool mayBlock, C2P<C2StreamColorAspectsInfo::output> &me,
                                  const C2P<C2StreamColorAspectsTuning::output> &def,
                                  const C2P<C2StreamColorAspectsInfo::input> &coded) {
        (void)mayBlock;
        // take default values for all unspecified fields, and coded values for specified ones
        me.set().range = coded.v.range == RANGE_UNSPECIFIED ? def.v.range : coded.v.range;
        me.set().primaries = coded.v.primaries == PRIMARIES_UNSPECIFIED
                ? def.v.primaries : coded.v.primaries;
        me.set().transfer = coded.v.transfer == TRANSFER_UNSPECIFIED
                ? def.v.transfer : coded.v.transfer;
        me.set().matrix = coded.v.matrix == MATRIX_UNSPECIFIED ? def.v.matrix : coded.v.matrix;
        return C2R::Ok();
    }

    std::shared_ptr<C2StreamColorAspectsInfo::output> getColorAspects_l() {
        return mColorAspects;
    }

private:
    std::shared_ptr<C2StreamProfileLevelInfo::input> mProfileLevel;
    std::shared_ptr<C2StreamPictureSizeInfo::output> mSize;
    std::shared_ptr<C2StreamMaxPictureSizeTuning::output> mMaxSize;
    std::shared_ptr<C2StreamMaxBufferSizeInfo::input> mMaxInputSize;
    std::shared_ptr<C2StreamColorInfo::output> mColorInfo;
    std::shared_ptr<C2StreamColorAspectsInfo::input> mCodedColorAspects;
    std::shared_ptr<C2StreamColorAspectsTuning::output> mDefaultColorAspects;
    std::shared_ptr<C2StreamColorAspectsInfo::output> mColorAspects;
    std::shared_ptr<C2StreamPixelFormatInfo::output> mPixelFormat;
};


C2SoftHevcDec::C2SoftHevcDec(const char* name, c2_node_id_t id,
        const std::shared_ptr<IntfImpl>& intf)
    : SimpleC2Component(std::make_shared<SimpleInterface<IntfImpl>>(name, id, intf)), mIntf(intf) {}

c2_status_t C2SoftHevcDec::onInit() {
    onRelease();
    mEos = mError = false;
    mWidth = mHeight = 0;
    mDecoder = de265_new_decoder();
    if (!mDecoder) return C2_NO_MEMORY;
    if (de265_start_worker_threads(mDecoder, std::max(1L, std::min(4L, sysconf(_SC_NPROCESSORS_ONLN)))) != DE265_OK) {
        onRelease(); return C2_NO_MEMORY;
    }
    return C2_OK;
}
c2_status_t C2SoftHevcDec::onStop() {
    if (mDecoder) de265_reset(mDecoder);
    mEos = mError = false;
    mWidth = mHeight = 0;
    return C2_OK;
}
void C2SoftHevcDec::onRelease() {
    if (mDecoder) de265_free_decoder(mDecoder);
    mDecoder = nullptr;
}

c2_status_t C2SoftHevcDec::output(const de265_image* image,
        const std::shared_ptr<C2BlockPool>& pool, const std::unique_ptr<C2Work>& work) {
    const int width = de265_get_image_width(image, 0), height = de265_get_image_height(image, 0);
    const int bits = de265_get_bits_per_pixel(image, 0);
    if (width < 2 || height < 2 || width > 4096 || height > 4096 ||
        (width & 1) || (height & 1) || (bits != 8 && bits != 10) ||
        de265_get_chroma_format(image) != de265_chroma_420) return C2_BAD_VALUE;
    std::shared_ptr<C2GraphicBlock> block;
    c2_status_t status = pool->fetchGraphicBlock((width + 127u) & ~127u, height,
        HAL_PIXEL_FORMAT_YV12, {C2MemoryUsage::CPU_READ, C2MemoryUsage::CPU_WRITE}, &block);
    if (status != C2_OK) return status;
    {
        C2GraphicView view = block->map().get();
        if (view.error() != C2_OK) return view.error();
        const C2PlanarLayout layout = view.layout();
        if (layout.type != C2PlanarLayout::TYPE_YUV || layout.numPlanes < 3) return C2_CORRUPTED;
        for (int plane = 0; plane < 3; ++plane) {
            int stride = 0;
            const uint8_t* src = de265_get_image_plane(image, plane, &stride);
            const int w = de265_get_image_width(image, plane), h = de265_get_image_height(image, plane);
            if (!src || !view.data()[plane] || stride < w * (bits > 8 ? 2 : 1) ||
                de265_get_bits_per_pixel(image, plane) != bits) return C2_CORRUPTED;
            for (int y = 0; y < h; ++y) {
                const uint8_t* row = src + y * stride;
                uint8_t* dest = view.data()[plane] + y * layout.planes[plane].rowInc;
                // Copy only active samples; keep row padding and non-planar
                // layouts unchanged, and retain Main10's rounding below.
                if (bits == 8 && layout.planes[plane].colInc == 1) {
                    memcpy(dest, row, static_cast<size_t>(w));
                    continue;
                }
                for (int x = 0; x < w; ++x) {
                    unsigned sample = row[x];
                    if (bits == 10) {
                        uint16_t value;
                        memcpy(&value, row + x * 2, sizeof(value));
                        sample = std::min(255u, (unsigned(value) + 2u) >> 2);
                    }
                    dest[x * layout.planes[plane].colInc] = sample;
                }
            }
        }
    }
    // Retain the original stream color aspects. Output is explicitly 8-bit YUV;
    // Main10 SDR is rounded to that format, never mislabeled P010 or HDR tone-mapped.
    ColorAspects aspects;
    C2StreamColorAspectsInfo::input coded(0u);
    ColorUtils::convertIsoColorAspectsToCodecAspects(de265_get_image_colour_primaries(image),
        de265_get_image_transfer_characteristics(image), de265_get_image_matrix_coefficients(image),
        de265_get_image_full_range_flag(image), aspects);
    C2Mapper::map(aspects.mPrimaries, &coded.primaries);
    C2Mapper::map(aspects.mTransfer, &coded.transfer);
    C2Mapper::map(aspects.mMatrixCoeffs, &coded.matrix);
    C2Mapper::map(aspects.mRange, &coded.range);
    C2StreamPictureSizeInfo::output size(0u, width, height);
    std::vector<std::unique_ptr<C2SettingResult>> failures;
    if (mIntf->config({&size, &coded}, C2_MAY_BLOCK, &failures) != C2_OK || !failures.empty())
        return C2_BAD_VALUE;
    auto buffer = createGraphicBuffer(std::move(block), C2Rect(width, height));
    {
        IntfImpl::Lock lock = mIntf->lock();
        buffer->setInfo(mIntf->getColorAspects_l());
    }
    const bool changed = width != mWidth || height != mHeight;
    if (changed) ALOGI("HEVC decoded width=%d height=%d input_bits=%d output_bits=8", width, height, bits);
    mWidth = width;
    mHeight = height;
    const uint64_t index = de265_get_image_PTS(image);
    auto fill = [buffer, width, height, changed](const std::unique_ptr<C2Work>& target) {
        target->result = C2_OK;
        target->workletsProcessed = 1;
        auto& out = target->worklets.front()->output;
        out.flags = C2FrameData::flags_t(0);
        out.ordinal = target->input.ordinal;
        out.buffers = {buffer};
        if (changed) out.configUpdate.push_back(std::make_unique<C2StreamPictureSizeInfo::output>(0u, width, height));
    };
    if (work && work->input.ordinal.frameIndex == c2_cntr64_t(index)) fill(work);
    else finish(index, fill);
    return C2_OK;
}

c2_status_t C2SoftHevcDec::decode(const std::shared_ptr<C2BlockPool>& pool,
        const std::unique_ptr<C2Work>& work) {
    int more = 1;
    // Bound malformed input without hiding decode errors or spinning forever.
    for (unsigned steps = 0; more && steps < 65536; ++steps) {
        de265_error error = de265_decode(mDecoder, &more);
        const de265_image* image;
        while ((image = de265_peek_next_picture(mDecoder)) != nullptr) {
            c2_status_t status = output(image, pool, work);
            de265_release_next_picture(mDecoder);
            if (status != C2_OK) return status;
        }
        if (error == DE265_ERROR_WAITING_FOR_INPUT_DATA) return C2_OK;
        if (error != DE265_OK && error != DE265_ERROR_IMAGE_BUFFER_FULL && !de265_isOK(error)) {
            ALOGE("HEVC decode: %s", de265_get_error_text(error));
            return C2_CORRUPTED;
        }
    }
    return more ? C2_CORRUPTED : C2_OK;
}

void C2SoftHevcDec::process(const std::unique_ptr<C2Work>& work,
        const std::shared_ptr<C2BlockPool>& pool) {
    work->result = C2_OK;
    work->workletsProcessed = 0;
    if (!mDecoder || mEos || mError) { work->result = C2_BAD_STATE; work->workletsProcessed = 1; return; }
    const bool config = work->input.flags & C2FrameData::FLAG_CODEC_CONFIG;
    const bool eos = work->input.flags & C2FrameData::FLAG_END_OF_STREAM;
    bool input = false;
    if (!work->input.buffers.empty()) {
        const auto& blocks = work->input.buffers.front()->data().linearBlocks();
        if (blocks.size() != 1) { work->result = C2_BAD_VALUE; work->workletsProcessed = 1; return; }
        C2ReadView view = blocks.front().map().get();
        if (view.error() != C2_OK || view.capacity() > 32u * 1024u * 1024u) {
            work->result = C2_BAD_VALUE; work->workletsProcessed = 1; return;
        }
        input = view.capacity() != 0;
        if (input && de265_push_data(mDecoder, view.data(), view.capacity(),
                work->input.ordinal.frameIndex.peekull(), nullptr) != DE265_OK) {
            work->result = C2_CORRUPTED; work->workletsProcessed = 1; mError = true; return;
        }
        // Close the final Annex-B NAL without flushing the DPB reorder queue.
        // push_end_of_frame drains it at every access unit, emitting B-frame
        // streams in decode order. Only actual EOS/drain may flush pictures.
        de265_push_end_of_NAL(mDecoder);
    }
    // push_data copies the access unit. Release the input allocation immediately
    // even when its work awaits a reordered output picture. Keeping it pinned
    // can exhaust MediaCodec's four input slots before the DPB emits a frame.
    work->input.buffers.clear();
    if (eos) de265_flush_data(mDecoder);
    work->result = decode(pool, work);
    if (work->result != C2_OK) { mError = true; work->workletsProcessed = 1; return; }
    if (config || eos || !input) {
        auto& out = work->worklets.front()->output;
        out.ordinal = work->input.ordinal;
        out.flags = eos ? C2FrameData::FLAG_END_OF_STREAM : C2FrameData::flags_t(0);
        work->workletsProcessed = 1;
    }
    mEos = eos;
}

c2_status_t C2SoftHevcDec::drain(uint32_t mode, const std::shared_ptr<C2BlockPool>& pool) {
    if (mode == NO_DRAIN) return C2_OK;
    if (mode == DRAIN_CHAIN) return C2_OMITTED;
    if (!mDecoder) return C2_BAD_STATE;
    de265_flush_data(mDecoder);
    const auto result = decode(pool, nullptr);
    if (mode == DRAIN_COMPONENT_WITH_EOS) mEos = true;
    return result;
}

class C2SoftHevcDecFactory : public C2ComponentFactory {
public:
    C2SoftHevcDecFactory() : mHelper(std::static_pointer_cast<C2ReflectorHelper>(
        GetCodec2PlatformComponentStore()->getParamReflector())) {
    }

    virtual c2_status_t createComponent(
            c2_node_id_t id,
            std::shared_ptr<C2Component>* const component,
            std::function<void(C2Component*)> deleter) override {
        *component = std::shared_ptr<C2Component>(
                new C2SoftHevcDec(COMPONENT_NAME,
                                 id,
                                 std::make_shared<C2SoftHevcDec::IntfImpl>(mHelper)),
                deleter);
        return C2_OK;
    }

    virtual c2_status_t createInterface(
            c2_node_id_t id,
            std::shared_ptr<C2ComponentInterface>* const interface,
            std::function<void(C2ComponentInterface*)> deleter) override {
        *interface = std::shared_ptr<C2ComponentInterface>(
                new SimpleInterface<C2SoftHevcDec::IntfImpl>(
                        COMPONENT_NAME, id, std::make_shared<C2SoftHevcDec::IntfImpl>(mHelper)),
                deleter);
        return C2_OK;
    }

    virtual ~C2SoftHevcDecFactory() override = default;

private:
    std::shared_ptr<C2ReflectorHelper> mHelper;
};

}  // namespace android

__attribute__((visibility("default")))
extern "C" ::C2ComponentFactory* CreateCodec2Factory() {
    ALOGV("in %s", __func__);
    return new ::android::C2SoftHevcDecFactory();
}

__attribute__((visibility("default")))
extern "C" void DestroyCodec2Factory(::C2ComponentFactory* factory) {
    ALOGV("in %s", __func__);
    delete factory;
}
