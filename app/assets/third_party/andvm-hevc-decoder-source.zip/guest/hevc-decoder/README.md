# Owned HEVC software decoder

Provides the standard Codec2 `c2.android.hevc.decoder` factory using libde265
1.0.16. Supports 8-bit Main and 10-bit Main10 4:2:0 streams, producing 8-bit YUV.
Main10 samples are rounded to 8-bit; stream color aspects are preserved. This is
not HDR tone mapping, hardware acceleration, or a real-time 4K/90-fps guarantee.
The runtime retains the ROM's codec XML limits and unrelated vendor components.

The component is installed only when the ROM declares the standard decoder and
has an arm64 media.swcodec APEX, and a disposable process successfully exercises
factory creation, configuration, backend initialization, EOS, stop and release.
Incompatible ABIs retain the original decoder and emit an explicit diagnostic.
No original APK, JAR, wallpaper or movie is modified.

Build (Python 3.12+, Android NDK 28.2.13676358, CMake and Ninja):

```
python3 tools/build_owned_hevc_decoder.py --out /tmp/hevc-build --ndk /path/to/ndk --cmake /path/to/cmake
```

The outputs `owned_hevcdec.arm64.so` and `hevcdec_probe.arm64` go in `guest/`;
`hevc-decoder.provenance.json` goes in this directory as `build.provenance.json`.
Run `build-guest-init.sh` to embed them and `gradlew :app:assembleDebug` to package.
The complete native build also performs these steps. Verification rejects stale
sources or artifacts. Generated link-only stub libraries are never distributed.

`abi_probe.cpp` accepts an optional final Annex-B HEVC file argument for device
tests. The two generated 64x64 fixtures exercise real 8/10-bit pixel output, EOS,
flush and decoder reuse; tests require functioning Guest graphic allocation.
They are generated from FFmpeg testsrc2 (one frame, libx265, yuv420p/yuv420p10le),
not copied from a ROM. The publication probe does not require graphic HAL startup.

Access units end with `de265_push_end_of_NAL`, not `push_end_of_frame`: the latter
prematurely drains libde265's picture reorder buffer and emits B-frame streams
in decode order. `libde265-reset.patch` clears the parser's EOS/frame markers
on reset while preserving parameter sets needed by Codec2 flush/reuse. Recreating
the entire backend on flush loses those parameter sets and is not equivalent.
The multi-frame regression is in `tools/experiments/hevc-order`; the one-frame
publication ABI probe alone cannot detect presentation-order failures.

## Corresponding source and licenses

libde265 is LGPL-3.0-or-later; the unmodified pinned source archive, local reset
patch and full license are included here. The build applies that patch and ships
it in the corresponding-source archive. Source URL:
https://github.com/strukturag/libde265/releases/tag/v1.0.16
The Codec2 interface/factory derives from AOSP's Apache-2.0 C2SoftHevcDec:
https://github.com/LineageOS/android_frameworks_av/blob/b6b36c1fdb3c6ffced822a054fbf035b544f0de2/media/codec2/components/hevc/C2SoftHevcDec.cpp
The backend and pixel/lifecycle bridge are implemented in this directory.

The combined decoder component is distributed with its corresponding source,
headers, build script and licenses in the APK asset
`third_party/andvm-hevc-decoder-source.zip`. Extract that asset, build with the
command above, and substitute the rebuilt component before rebuilding Guest init.
The component can also be bind-mounted at the Guest media.swcodec library path
for development. Modifying/relinking/debugging this LGPL component is permitted.
The source archive and headers retain their respective copyright notices.
