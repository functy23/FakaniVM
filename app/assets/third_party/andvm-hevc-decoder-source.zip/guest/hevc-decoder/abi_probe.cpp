// Validate the platform Codec2 ABI in a disposable process before publication.
// A missing symbol, incompatible vtable, or rejected size must not kill mediaswcodec.
#include <C2Config.h>
#include <C2PlatformSupport.h>

#include <C2ComponentFactory.h>
#include <dlfcn.h>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <memory>
#include <vector>
#include <condition_variable>
#include <mutex>
#include <chrono>

class ProbeListener final : public C2Component::Listener {
public:
    bool expectPixels = false;
    void reset() { std::lock_guard<std::mutex> lock(mutex); done = ok = false; }
    bool wait() {
        std::unique_lock<std::mutex> lock(mutex);
        return ready.wait_for(lock, std::chrono::seconds(10), [&] { return done; }) && ok;
    }
private:
    std::mutex mutex;
    std::condition_variable ready;
    bool done = false, ok = false;
    void onWorkDone_nb(std::weak_ptr<C2Component>, std::list<std::unique_ptr<C2Work>> work) override {
        std::lock_guard<std::mutex> lock(mutex);
        done = true;
        ok = work.size() == 1 && work.front()->result == C2_OK &&
             work.front()->workletsProcessed == 1;
        if (ok && expectPixels) {
            const auto& buffers = work.front()->worklets.front()->output.buffers;
            ok = buffers.size() == 1 && buffers.front()->data().graphicBlocks().size() == 1;
            if (ok) {
                auto view = buffers.front()->data().graphicBlocks().front().map().get();
                ok = view.error() == C2_OK;
                if (ok) {
                    auto layout = view.layout();
                    const auto* data = view.data()[0];
                    unsigned lo = 255, hi = 0;
                    for (unsigned y = 0; y < 64; ++y) for (unsigned x = 0; x < 64; ++x) {
                        unsigned sample = data[y * layout.planes[0].rowInc + x * layout.planes[0].colInc];
                        lo = std::min(lo, sample); hi = std::max(hi, sample);
                    }
                    ok = hi > lo + 32;
                }
            }
        }
        ready.notify_one();
    }
    void onTripped_nb(std::weak_ptr<C2Component>, std::vector<std::shared_ptr<C2SettingResult>>) override {}
    void onError_nb(std::weak_ptr<C2Component>, uint32_t) override {
        std::lock_guard<std::mutex> lock(mutex);
        done = true;
        ok = false;
        ready.notify_one();
    }
};

int main(int argc, char** argv) {
    if (argc != 5 && argc != 6) return 2;
    const bool hevc = strcmp(argv[4], "c2.android.hevc.decoder") == 0;
    if (!hevc) return 2;
    char *endWidth = nullptr, *endHeight = nullptr;
    const long width = strtol(argv[2], &endWidth, 10);
    const long height = strtol(argv[3], &endHeight, 10);
    if (*endWidth || *endHeight || width < 16 || height < 16 || width > 4096 ||
            height > 4096 || width % 2 || height % 2 ||
            (hevc ? (width < 64 || height < 64 || width * height > 8912896) :
             ((width + 15) / 16) * ((height + 15) / 16) > 36864)) return 2;
    void* library = dlopen(argv[1], RTLD_NOW | RTLD_LOCAL);
    if (!library) { fprintf(stderr, "dlopen: %s\n", dlerror()); return 3; }
    auto create = reinterpret_cast<C2ComponentFactory* (*)()>(dlsym(library, "CreateCodec2Factory"));
    auto destroy = reinterpret_cast<void (*)(C2ComponentFactory*)>(dlsym(library, "DestroyCodec2Factory"));
    if (!create || !destroy) return 4;
    std::unique_ptr<C2ComponentFactory, decltype(destroy)> factory(create(), destroy);
    if (!factory) return 5;
    std::shared_ptr<C2ComponentInterface> interface;
    if (factory->createInterface(0, &interface, [](C2ComponentInterface* p) { delete p; }) != C2_OK ||
            !interface || interface->getName() != argv[4]) return 6;
    C2StreamPictureSizeInfo::output requested(0u, uint32_t(width), uint32_t(height));
    std::vector<std::unique_ptr<C2SettingResult>> failures;
    if (interface->config_vb({&requested}, C2_MAY_BLOCK, &failures) != C2_OK || !failures.empty()) return 7;
    C2StreamPictureSizeInfo::output actual(0u, 0, 0);
    std::vector<std::unique_ptr<C2Param>> params;
    if (interface->query_vb({&actual}, {}, C2_MAY_BLOCK, &params) != C2_OK ||
            actual.width != width || actual.height != height) return 8;
    std::shared_ptr<C2Component> component;
    auto listener = std::make_shared<ProbeListener>();
    if (factory->createComponent(1, &component, [](C2Component* p) { delete p; }) != C2_OK ||
            !component || component->intf()->config_vb({&requested}, C2_MAY_BLOCK, &failures) != C2_OK ||
            !failures.empty() ||
            component->setListener_vb(listener, C2_MAY_BLOCK) != C2_OK ||
            component->start() != C2_OK) return 9;
    // Runtime publication needs only the ABI/backend lifecycle check. Passing a
    // test stream additionally exercises graphic allocation, pixel output and flush.
    listener->expectPixels = argc == 6;
    for (unsigned round = 0; round < (argc == 6 ? 2u : 1u); ++round) {
        std::list<std::unique_ptr<C2Work>> pending;
        auto work = std::make_unique<C2Work>();
        work->input.flags = C2FrameData::FLAG_END_OF_STREAM;
        work->input.ordinal.timestamp = 0;
        work->input.ordinal.frameIndex = round;
        work->worklets.emplace_back(std::make_unique<C2Worklet>());
        if (argc == 6) {
            FILE* stream = fopen(argv[5], "rb");
            if (!stream) return 12;
            fseek(stream, 0, SEEK_END);
            const long size = ftell(stream);
            rewind(stream);
            if (size <= 0 || size > 1024 * 1024) { fclose(stream); return 12; }
            std::vector<char> bytes(size);
            if (fread(bytes.data(), 1, size, stream) != size) { fclose(stream); return 12; }
            fclose(stream);
            std::shared_ptr<C2BlockPool> pool;
            if (android::GetCodec2BlockPool(C2BlockPool::BASIC_LINEAR, component, &pool) != C2_OK) return 13;
            std::shared_ptr<C2LinearBlock> block;
            if (pool->fetchLinearBlock(bytes.size(), {C2MemoryUsage::CPU_READ, C2MemoryUsage::CPU_WRITE}, &block) != C2_OK) return 14;
            {
                auto view = block->map().get();
                if (view.error() != C2_OK) return 15;
                memcpy(view.data(), bytes.data(), bytes.size());
            }
            work->input.buffers.push_back(C2Buffer::CreateLinearBuffer(block->share(0, bytes.size(), C2Fence())));
        }
        pending.emplace_back(std::move(work));
        listener->reset();
        if (component->queue_nb(&pending) != C2_OK || !listener->wait()) return 11;
        if (round == 0 && argc == 6) {
            std::list<std::unique_ptr<C2Work>> flushed;
            if (component->flush_sm(C2Component::FLUSH_COMPONENT, &flushed) != C2_OK) return 16;
        }
    }
    if (component->stop() != C2_OK || component->release() != C2_OK) return 10;
    component.reset();
    interface.reset();
    factory.reset();
    // Process exit tears down the platform singleton; don't dlclose underneath it.
    printf("ANDVM_CODEC_PROBE ready component=%s width=%ld height=%ld\n", argv[4], width, height);
    return 0;
}
