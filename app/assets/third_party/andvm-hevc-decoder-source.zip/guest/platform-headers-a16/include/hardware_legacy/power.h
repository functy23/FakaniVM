/*
 * Copyright (C) 2008 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 */

#ifndef ANDVM_HARDWARE_LEGACY_POWER_H
#define ANDVM_HARDWARE_LEGACY_POWER_H

#ifdef __cplusplus
extern "C" {
#endif

enum { PARTIAL_WAKE_LOCK = 1, FULL_WAKE_LOCK = 2 };

int acquire_wake_lock(int lock, const char* id);
int release_wake_lock(const char* id);

#ifdef __cplusplus
}
#endif

#endif
