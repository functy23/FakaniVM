#!/usr/bin/env python3
"""Build the replaceable Codec2 HEVC Main/Main10 software decoder without a ROM.

Platform stub DSOs are link-only contracts and must never be packaged.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path
import platform
import shutil
import subprocess
import tarfile
import zipfile


def inputs(root):
    paths = list((root / "guest/hevc-decoder").rglob("*"))
    for name in ["guest/platform-libcxx", "guest/platform-headers-a16/include", "guest/video-codecs/include"]:
        paths += list((root / name).rglob("*"))
    paths += [Path(__file__).resolve(), root / "guest/video-codecs/platform-symbols.json", root / "guest/video-codecs/exports.lds"]
    return sorted(p for p in paths if p.is_file() and p.name != "build.provenance.json")


def identity(root):
    digest = hashlib.sha256()
    for path in inputs(root):
        digest.update(str(path.relative_to(root)).encode() + b"\0" + path.read_bytes())
    return digest.hexdigest()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--out", type=Path)
    parser.add_argument("--verify-packaged", action="store_true")
    parser.add_argument("--verify-init", action="store_true")
    parser.add_argument("--ndk", type=Path, default=Path(os.environ.get("ANDROID_NDK_ROOT", str(Path.home() / "Library/Android/sdk/ndk/28.2.13676358"))))
    parser.add_argument("--cmake", default=shutil.which("cmake") or str(Path.home() / "Library/Android/sdk/cmake/3.22.1/bin/cmake"))
    args = parser.parse_args()
    root = Path(__file__).resolve().parents[1]
    src = root / "guest/hevc-decoder"
    source_sha = identity(root)
    names = ["owned_hevcdec.arm64.so", "hevcdec_probe.arm64"]
    if args.verify_packaged:
        provenance = json.loads((src / "build.provenance.json").read_text())
        if provenance["source_sha256"] != source_sha:
            raise SystemExit("HEVC decoder source changed; rebuild decoder and ABI probe")
        for name in names:
            if hashlib.sha256((root / "guest" / name).read_bytes()).hexdigest() != provenance["artifacts"][name]:
                raise SystemExit("HEVC decoder artifact mismatch: " + name)
        if args.verify_init:
            init = (root / "app/src/main/jniLibs/arm64-v8a/libandvm_guest_init.so").read_bytes()
            for name in names:
                if (root / "guest" / name).read_bytes() not in init:
                    raise SystemExit("Guest init embeds an old HEVC decoder; run build-guest-init.sh")
        source_zip = root / "app/src/main/assets/third_party/andvm-hevc-decoder-source.zip"
        with zipfile.ZipFile(source_zip) as archive:
            for path in inputs(root):
                if archive.read(str(path.relative_to(root))) != path.read_bytes():
                    raise SystemExit("HEVC decoder corresponding-source archive is stale")
        print("PASS HEVC decoder source and packaged artifact provenance")
        return
    if args.out is None:
        parser.error("--out is required")
    out = args.out.resolve()
    out.mkdir(parents=True, exist_ok=True)
    host = "darwin-x86_64" if platform.system() == "Darwin" else "linux-x86_64"
    toolchain = args.ndk / "toolchains/llvm/prebuilt" / host / "bin"
    cc, cxx = [toolchain / ("aarch64-linux-android31-" + name) for name in ["clang", "clang++"]]
    def run(command):
        subprocess.run([str(x) for x in command], check=True)
    # Bind extraction to both the pinned archive and the carried local fix.
    backend_patch = src / "libde265-reset.patch"
    archive_sha = hashlib.sha256((src / "libde265-1.0.16.tar.gz").read_bytes()
                                 + backend_patch.read_bytes()).hexdigest()
    stamp = out / "backend-source.sha256"
    if not stamp.exists() or stamp.read_text() != archive_sha:
        with tarfile.open(src / "libde265-1.0.16.tar.gz") as archive:
            archive.extractall(out, filter="data")
        subprocess.run(["patch", "-p1", "-i", str(backend_patch)],
                       cwd=out / "libde265-1.0.16", check=True)
        stamp.write_text(archive_sha)
    backend, build = out / "libde265-1.0.16", out / "backend-build"
    ninja = shutil.which("ninja") or str(Path(args.cmake).parent / "ninja")
    run([args.cmake, "-S", backend, "-B", build, "-G", "Ninja", "-DCMAKE_MAKE_PROGRAM=" + ninja,
         "-DCMAKE_TOOLCHAIN_FILE=" + str(args.ndk / "build/cmake/android.toolchain.cmake"),
         "-DANDROID_ABI=arm64-v8a", "-DANDROID_PLATFORM=android-31", "-DCMAKE_BUILD_TYPE=Release",
         "-DENABLE_DECODER=OFF", "-DENABLE_ENCODER=OFF", "-DENABLE_SDL=OFF", "-DBUILD_SHARED_LIBS=OFF"])
    run([args.cmake, "--build", build, "--target", "de265", "-j", "6"])
    symbols = json.loads((root / "guest/video-codecs/platform-symbols.json").read_text())
    for name, exports in json.loads((src / "platform-symbols.json").read_text()).items():
        symbols.setdefault(name, {}).update(exports)
    stubs = out / "link-only"
    stubs.mkdir(exist_ok=True)
    libraries = []
    for name, exports in symbols.items():
        asm = stubs / (name + ".S")
        lines = []
        for symbol, kind in exports.items():
            lines += [".data" if kind == "object" else ".text", ".p2align 3", f".global {symbol}",
                      f".type {symbol}, %{kind}", symbol + ":", ".quad 0" if kind == "object" else "ret"]
        asm.write_text("\n".join(lines) + "\n")
        library = stubs / name
        run([cc, "-shared", "-nostdlib", f"-Wl,-soname,{name}", asm, "-o", library])
        libraries.append(library)
    flags = ["-std=c++17", "-O2", "-fPIC", "-fvisibility=hidden", "-fno-rtti",
             f"-ffile-prefix-map={root}=/andvm-hevc/source", f"-ffile-prefix-map={out}=/andvm-hevc/build"]
    flags += ["-I" + str(root / name) for name in ["guest/platform-libcxx", "guest/video-codecs/include", "guest/platform-headers-a16/include"]]
    flags += ["-I" + str(backend), "-I" + str(build)]
    link = ["-Wl,--no-undefined", "-Wl,--exclude-libs,ALL", "-Wl,-z,max-page-size=16384"]
    dependencies = ["-Wl,--no-as-needed", *libraries, "-llog", "-ldl", "-lm"]
    run([cxx, *flags, "-c", src / "C2AndVmHevcDec.cpp", "-o", out / "decoder.o"])
    # libde265 uses the NDK std::__ndk1 ABI; keep it private. Codec2 uses the ROM's
    # std::__1 ABI via platform headers and the real libc++.so dependency.
    run([cxx, "-shared", "-static-libstdc++", *link, "-Wl,-soname,libcodec2_soft_hevcdec.so",
         "-Wl,--version-script=" + str(root / "guest/video-codecs/exports.lds"), out / "decoder.o",
         build / "libde265/libde265.a", *dependencies, "-o", out / names[0]])
    run([cxx, *flags, "-fPIE", "-pie", "-nostdlib++", *link, src / "abi_probe.cpp", *dependencies, "-o", out / names[1]])
    for name in names:
        run([toolchain / "llvm-strip", "--strip-unneeded", out / name])
    if identity(root) != source_sha:
        raise SystemExit("HEVC decoder source changed during build")
    provenance = {"source_sha256": source_sha, "target": "aarch64-linux-android31",
                  "compiler": subprocess.check_output([str(cxx), "--version"], text=True).splitlines()[0],
                  "artifacts": {name: hashlib.sha256((out / name).read_bytes()).hexdigest() for name in names}}
    (out / "hevc-decoder.provenance.json").write_text(json.dumps(provenance, indent=2) + "\n")
    # Carry the decoder's corresponding source and licenses with distributed APKs.
    with zipfile.ZipFile(out / "andvm-hevc-decoder-source.zip", "w", zipfile.ZIP_DEFLATED) as archive:
        for path in inputs(root):
            info = zipfile.ZipInfo(str(path.relative_to(root)), (2026, 1, 1, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            archive.writestr(info, path.read_bytes())
    print(json.dumps(provenance, indent=2))


if __name__ == "__main__":
    main()
